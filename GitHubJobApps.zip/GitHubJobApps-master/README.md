# GitHubJobApps

Aplikasi android untuk menampilkan daftar job pada https://jobs.github.com/ yang mau belajar menggunakan API silahkan coba pelajari source code pada aplikasi ini.

Aplikasi daftar job ini di bungkus dengan rapih dan mudah di pahami sehinggah mudah dipelajari bagi pemula. good job!

This Application is very recommended for who are looking for job opportunities!

Semoga dengan adanya project ini bisa membantu teman teman bisa mengembangkan skill dalam mengerjakan project android
Terima kasih ^-^

